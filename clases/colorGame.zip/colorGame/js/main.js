document.body.style.backgroundColor = "darkgreen";

function random_item(items){
    return items[Math.floor(Math.random()*items.length)];
}

const randomBetween = (min, max) => min + Math.floor(Math.random() * (max - min + 1));

// let colores = []

// for (i = 0; i < 6; i++) {
//     colorGanador= `rgb(${randomBetween(0, 255)}, ${randomBetween(0, 255)}, ${randomBetween(0, 255)})`
//     colores.push(colorGanador)
// }  

let container = document.querySelectorAll("#cuadrado")

let color = document.querySelector("#colorDisplay")

let itemGanador

let colorFondo = document.body.style.backgroundColor

let msg = document.querySelector("#message")

let resetear = document.querySelector("#reset")

let colorElegido

let crearColores = function(){
    itemGanador = random_item(container)
    container.forEach(element => {
        rgb = `rgb(${randomBetween(0, 255)}, ${randomBetween(0, 255)}, ${randomBetween(0, 255)})`
        element.style.backgroundColor=rgb
        colorElegido = itemGanador.style.backgroundColor
        color.textContent=colorElegido
        element.addEventListener("click", function(){
            if (element.style.backgroundColor == colorElegido) {
                container.forEach(element => {
                    element.style.backgroundColor = colorElegido
                })
                msg.textContent="Correcto!"
            } else {
                element.style.backgroundColor = colorFondo
                msg.textContent="Intentalo nuevamente"
            }
        });
    });
}

crearColores()

resetear.addEventListener("click", function(){
    itemGanador=random_item(container)
    colorElegido = itemGanador.style.backgroundColor
    color.textContent=colorElegido
    crearColores()
})




